# LC-Game-Master-Suit
Adds The Game Master (Entity 99 of the Backrooms) to Lethal Company as a suit
